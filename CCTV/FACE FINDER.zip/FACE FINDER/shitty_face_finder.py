'''
TITLE: Shitty Face Finder
BY:
    Some Guy they call Scooter
    Common Sense Cyber Group

Created: 11/19/2021
Updated: 11/19/2021

Version: 1.0.1

License: MIT

Purpose and Disclaimer:
    -This script is JUST used to iterate through a bunch of image files, and look to see if we can tell if they have faces or not
    -We run the images through both Harr Cascade and LBP so if one misses a face, the other may catch it. (ALTHOUGH HARR SEEMS TO ALWAYS FIND MORE)
    -We also try to look for profile faces as well
    -YOU NEED TO SHANCE LINE 84 (path = ) BELOW TO THE PATH YOU WANT - I AM TOO LAZY TO MAKE IT AN INPUT

    ***
    This is ugly and not well written. Not really meant to be. It is supposed to be a quick, dirty way to just get pictures where a face can be detected
    so they can be used in an actual facial recognition dataset for the BlueSS software suite
    ***
'''

###Import Libraries
from cv2 import cv2     #cv2 library for image and video processing
from datetime import datetime   #Processing dates and times
import os   #OS shit
from os.path import dirname   #For using OS features on the local machine

###Define Variables
project_root = dirname(__file__)   #Defines the root directory the script is currently in
harr_save_location = project_root + "\\Face_Capture_Pics\\Harr\\" #Location to save images for further processing
lbp_save_location = project_root + "\\Face_Capture_Pics\\LBP\\" #Location to save images for further processing
names = ["test"]
name = "test"


def do_the_shit():
    ### HARR FIRST ###
    #Convert image to Greyscale for haarcascade
    faces = cv2.CascadeClassifier(project_root + '\\Detection Algorythms\\frontal_default.xml').detectMultiScale(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY),scaleFactor=1.1,minNeighbors=5,minSize=(60, 60),flags=cv2.CASCADE_SCALE_IMAGE)
    profile_faces = cv2.CascadeClassifier(project_root + '\\Detection Algorythms\\profile_face.xml').detectMultiScale(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY),scaleFactor=1.1,minNeighbors=5,minSize=(60, 60),flags=cv2.CASCADE_SCALE_IMAGE)

    #Loop through the recognized faces (frontal)
    for ((x, y, w, h), name) in zip(faces, names):
        #Rescale the face coordinates and draw the predicted face name on the image
        cv2.rectangle(image, (x, y), (x + w, y + h), (0, 0, 255), 1)

        #Save the image for processing later
        cv2.imwrite(datetime.now().strftime(f'{harr_save_location}{"%Y%m%d-%H%M%S%f_face.png"}'), image)

    #Loop through the recognized faces (frontal)
    for ((x, y, w, h), name) in zip(profile_faces, names):
        #Rescale the face coordinates and draw the predicted face name on the image
        cv2.rectangle(image, (x, y), (x + w, y + h), (0, 0, 255), 1)

        #Save the image for processing later
        cv2.imwrite(datetime.now().strftime(f'{harr_save_location}{"%Y%m%d-%H%M%S%f_face.png"}'), image)

    ### LBP NEXT ###
    #Convert image to Greyscale for haarcascade
    faces = cv2.CascadeClassifier(project_root + '\\Detection Algorythms\\lbp_frontal_face.xml').detectMultiScale(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY),scaleFactor=1.1,minNeighbors=5,minSize=(60, 60),flags=cv2.CASCADE_SCALE_IMAGE)
    profile_faces = cv2.CascadeClassifier(project_root + '\\Detection Algorythms\\lbp_profile_face.xml').detectMultiScale(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY),scaleFactor=1.1,minNeighbors=5,minSize=(60, 60),flags=cv2.CASCADE_SCALE_IMAGE)

    #Loop through the recognized faces (frontal)
    for ((x, y, w, h), name) in zip(faces, names):
        #Rescale the face coordinates and draw the predicted face name on the image
        cv2.rectangle(image, (x, y), (x + w, y + h), (0, 0, 255), 1)

        #Save the image for processing later
        cv2.imwrite(datetime.now().strftime(f'{lbp_save_location}{"%Y%m%d-%H%M%S%f_face.png"}'), image)

    #Loop through the recognized faces (frontal)
    for ((x, y, w, h), name) in zip(profile_faces, names):
        #Rescale the face coordinates and draw the predicted face name on the image
        cv2.rectangle(image, (x, y), (x + w, y + h), (0, 0, 255), 1)

        #Save the image for processing later
        cv2.imwrite(datetime.now().strftime(f'{lbp_save_location}{"%Y%m%d-%H%M%S%f_face.png"}'), image)

if __name__ == '__main__':
    path = "CHANGEME"
    for root, directories, file in os.walk(path):
        for item in file:
            image = cv2.imread(f'{root}\\{item}')
            do_the_shit()